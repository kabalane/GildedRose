﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GildedRose.Controllers;
using GildedRose.Models;
using System.Collections.Generic;
using System.Net.Http;
using System.Web.Http;
namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1F
    {
        [TestMethod]
        public void TestMockDataBaseSucceeded()
        {
            //Arrange
            ValuesV1Controller controller = new ValuesV1Controller();
            //Act
            List<ItemV1> ItemV1s = controller.ItemV1Database();
            //Assert
            Assert.IsTrue(ItemV1s.Count > 0);
        }

        [TestMethod]
        public void TestGetSucceeded()
        {
            //Arrange
            ValuesV1Controller controller = new ValuesV1Controller();
            //Act
            IEnumerable<ItemV1> ItemV1s = controller.Get();
            //Assert
            Assert.IsNotNull(ItemV1s);
        }

        [TestMethod]
        public void TestValidateSucceeded()
        {
            //Arrange
            ValuesV1Controller controller = new ValuesV1Controller();
            //Act
            bool result = controller.Validate("test", "test");
            //Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void TestValidateUserUpperCaseSucceeded()
        {
            //Arrange
            ValuesV1Controller controller = new ValuesV1Controller();
            //Act
            bool result = controller.Validate("Test", "test");
            //Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void TestValidateInvalidUserNameFailed()
        {
            //Arrange
            ValuesV1Controller controller = new ValuesV1Controller();
            //Act
            bool result = controller.Validate("xyz", "test");
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void TestValidateInvalidPasswordFailed()
        {
            //Arrange
            ValuesV1Controller controller = new ValuesV1Controller();
            //Act
            bool result = controller.Validate("test", "xyz");
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void TestValidateUpperCasePasswordFailed()
        {
            //Arrange
            ValuesV1Controller controller = new ValuesV1Controller();
            //Act
            bool result = controller.Validate("test", "Test");
            //Assert
            Assert.IsFalse(result);
        }
        public void TestValidateNoAuthenticationFailed()
        {
            //Arrange
            ValuesV1Controller controller = new ValuesV1Controller();
            //Act
            bool result = controller.Validate(null, null);
            //Assert
            Assert.IsFalse(result);
        }

        //test buy()
        [TestMethod]
        public void TestBuyCheckPriceSucceeded()
        {
            //Arrange
            ValuesV1Controller controller = new ValuesV1Controller();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            //add headers
            controller.Request.Headers.Add("username", "test");
            controller.Request.Headers.Add("password", "test");
            //Act
            var response = controller.Buy(1, 4);
            //Assert. In the Mock Database, the price of Item 1 is 25.
            Assert.AreEqual("100.00", response);
        }

    }
}