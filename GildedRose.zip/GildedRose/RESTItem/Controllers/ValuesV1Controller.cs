﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GildedRose.Models;
namespace GildedRose.Controllers
{
    public class ValuesV1Controller : ApiController
    {
        // GET api/v1/values
        public IEnumerable<ItemV1> Get()
        {
            return ItemV1Database();
        }

        // GET api/v1/values/5
        public ItemV1 Get(int id)
        {
            List<ItemV1> ItemList = ItemV1Database();
            for (int i = 0; i < ItemList.Count; i++)
            {
                if (ItemList[i].Id == id)
                    return ItemList[i];
            }
            return null;
        }

        // GET api/v1/values/Buy/id/quantity
        [HttpGet]
        public String Buy(int id, int quantity)
        {

            //authenticate
            var re = Request;
            var headers = re.Headers;
            string username="";
            string password="";
            if (headers.Contains("username"))
            {
                username = headers.GetValues("username").First();
            }
            else
            {
                return "Authentication failed";
            }
            if (headers.Contains("password"))
            {
                password = headers.GetValues("password").First();
            }
            else
            {
                return "Authentication failed";
            }
            if (!Validate(username, password))
            {
                return "Authentication failed";
            }
            List<ItemV1> ItemList = ItemV1Database();
            for (int i = 0; i < ItemList.Count; i++)
            {
                if (ItemList[i].Id == id)
                    return (ItemList[i].Price * quantity).ToString("N2");
            }
            return "No data found for given id";
        }

        // POST api/v1/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/v1/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/v1/values/5
        public void Delete(int id)
        {
        }
        //mock user and password to be sent in header
        public bool Validate(string username, string password)
        {
            return username.Equals("test", StringComparison.OrdinalIgnoreCase)
                    && password == "test";

        }
        //helper method to create mock database
        public List<ItemV1> ItemV1Database()
        {
            //create a mock database
            List<ItemV1> ItemList = new List<ItemV1>();
            for (int i = 1; i < 11; i++)
            {
                var ItemV1 = new ItemV1
                {
                    Id = i,
                    Name = "Item  " + i,
                    Description = "Item Description " + i,
                    Price = i + 24
                };
                ItemList.Add(ItemV1);
            }
            return ItemList;
        }       
    }
}