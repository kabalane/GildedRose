﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace GildedRose
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.Routes.MapHttpRoute(
                name: "DefaultApiV1",
                routeTemplate: "api/v1/values/{id}",
                defaults: new { id = RouteParameter.Optional, controller = "ValuesV1" }
            );

            config.Routes.MapHttpRoute(
                name: "CustomApiV1",
                routeTemplate: "api/v1/values/Buy/{id}/{quantity}",
                defaults: new { id = RouteParameter.Optional, controller = "ValuesV1" }
            );

            config.Routes.MapHttpRoute(
                name: "DefaultApiV2",
                routeTemplate: "api/v2/values/{id}",
                defaults: new { id = RouteParameter.Optional, controller = "ValuesV2" }
            );

            config.Routes.MapHttpRoute(
                name: "CustomApiV2",
                routeTemplate: "api/v2/values/Buy/{id}/{quantity}",
                defaults: new { id = RouteParameter.Optional, controller = "ValuesV2" }
            );

            // WebAPI when dealing with JSON & JavaScript!  
            // Setup json serialization to serialize classes to camel (std. Json format)  
            var formatter = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            formatter.SerializerSettings.Formatting = Newtonsoft.Json.Formatting.Indented;
            formatter.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver();

            // Adding JSON type web api formatting.  
            config.Formatters.Clear();
            config.Formatters.Add(formatter);

            // Uncomment the following line of code to enable query support for actions with an IQueryable or IQueryable<T> return type.
            // To avoid processing unexpected or malicious queries, use the validation settings on QueryableAttribute to validate incoming queries.
            // For more information, visit http://go.microsoft.com/fwlink/?LinkId=279712.
            //config.EnableQuerySupport();

            // To disable tracing in your application, please comment out or remove the following line of code
            // For more information, refer to: http://www.asp.net/web-api
            config.EnableSystemDiagnosticsTracing();
        }
    }
}
